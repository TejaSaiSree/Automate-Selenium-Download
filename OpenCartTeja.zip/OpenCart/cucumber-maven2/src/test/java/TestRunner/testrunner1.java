package TestRunner;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="src\\main\\resources\\Feature",glue="Login_Def")
public class testrunner1 extends AbstractTestNGCucumberTests{

}
