package TestRunner;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="src\\main\\resources\\Feature2",glue="SearchP")
public class testrunner3 extends AbstractTestNGCucumberTests{

}