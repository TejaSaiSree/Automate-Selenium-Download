package Desktops;

import org.openqa.selenium.WebDriver;

import PomPages.AddandVerifyP;
import PomPages.DesktopVerification;
import Utiles.ExplicitCode;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excel_utilities.getexcel;

public class VerifyDesktops extends getexcel{
	WebDriver dr;
	
	DesktopVerification h= new  DesktopVerification (dr);
	 
	ExplicitCode e= new ExplicitCode();
	getexcel g= new getexcel();
	@Given("^launch the browser$")
	public void launch_the_browser() throws Throwable {
		e.launchbrowser("chrome");
		 g.getExcel("Sheet1");  
	}

	@When("^Click the Dektops in the page$")
	public void click_the_Dektops_in_the_page() throws Throwable {
	   h.VerifyDe();
	}

	@Then("^verify the clicking the desktops$")
	public void verify_the_clicking_the_desktops() throws Throwable {
	    String s=h.GetName();
	    System.out.println(s);
	}
}
