package testng;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Utilities.ExplicitCode;
import pages.Firstpage;

public class NewTest extends ExplicitCode {
	
	@BeforeClass
	public void lb() {
	launchbrowser("chrome","https://www.selenium.dev/");	
	}
  @Test
  public void f() {
	 Firstpage f= new Firstpage(dr); 
		f.downloading();
	
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 boolean b=f.Check();
	 Assert.assertTrue(b);
	 dr.close();
  }
}
