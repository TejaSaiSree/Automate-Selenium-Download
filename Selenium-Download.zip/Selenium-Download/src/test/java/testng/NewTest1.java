package testng;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Utilities.ExplicitCode;
import pages.Firstpage;
import pages.Secondpage;

public class NewTest1 extends ExplicitCode {

	@BeforeClass
	public void lb() {
	launchbrowser("chrome","https://www.selenium.dev/");	
	}
  @Test
  public void f() {
	 Secondpage f= new Secondpage(dr); 
		f.clicking(); 
		 dr.close();
  }
}
