package pages;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.ExplicitCode;

public class Firstpage {
WebDriver dr;
ExplicitCode e;
public Firstpage(WebDriver dr) {
	this.dr=dr;
	e= new ExplicitCode();
}
By downloads= By.xpath("//nav[@class='navbar']//a[@class='nav-item'][1]");
By bit=By.xpath("//div[@class='split-section container']//div[2]//a[2]");
public void clickdown() {
	WebElement wait= e.clickable(downloads,50);
	wait.click();
}
public void click64down() {
	WebElement wait= e.clickable(bit,50);
	wait.click();
}
public void downloading()
{
	this.clickdown();
	this.click64down();
	}
public Boolean Check() {
	boolean b=false;
	try {
	File f=new File("Downloads\\IEDriverServer_x64_3.150.1");
	b=true;
	}catch(Exception e) {
		b=false;
	}
	return b;
}
  }

