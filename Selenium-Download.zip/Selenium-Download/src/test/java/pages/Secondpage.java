package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.ExplicitCode;

public class Secondpage {
	WebDriver dr;
	ExplicitCode e;
	public Secondpage(WebDriver dr) {
		this.dr=dr;
		e= new ExplicitCode();
	}
	By downloads= By.xpath("//nav[@class='navbar']//a[@class='nav-item'][1]");
	By Documentation = By.xpath("//nav[@class='navbar']//a[@class='nav-item'][3]");
	By grid=By.xpath("//ul[@class='topics']//li[@title='Grid']");
	By whengrid=By.xpath("//div[@id='navigation']//a[2]//i");
	public void clickdown() {
		WebElement wait= e.clickable(downloads,50);
		wait.click();
	}
	public void clickdocu() {
		WebElement wait= e.clickable(Documentation,50);
		wait.click();
	}
	public void clickgrid() {
		WebElement wait= e.clickable(grid,50);
		wait.click();
	}
	public void clickwhengrid() {
		WebElement wait= e.clickable(whengrid,50);
		wait.click();
	}
	public void clicking() {
		this.clickdown();
		this.clickdocu();
		this.clickgrid();
		for(int i=0;i<=3;i++) {
			this.clickwhengrid();
		}
		
		e.Screenshot();
	}
	
}
