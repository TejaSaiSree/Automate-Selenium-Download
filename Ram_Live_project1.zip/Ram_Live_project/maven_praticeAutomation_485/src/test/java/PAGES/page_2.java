package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilites.libraries;

public class page_2 extends libraries
{
	WebDriver dr;
	
	WebElement we;
	
	public page_2(WebDriver dr)
	{
		this.dr=dr;
				
	}
	
	By email= By.xpath("//form[@class='register']//input[1][@type='email']");//xpath for email
	By password=By.xpath("//form[@class='register']//input[@type='password']");//xpath for password
	By button=By.xpath("//form[@class='register']//input[@type='submit']");//xpath for button
	By uid=By.xpath("//form[@class='login']//input[@name='username']");//xpath for uid
	By pwd=By.xpath("//form[@class='login']//input[@name='password']");//xpath for password
	By submit=By.xpath("//form[@class='login']//input[@type='submit']");//xpath for submit
	
	public void eid(String e)
	{
		we=waitelement(email,20);
		we.sendKeys(e);
	}
	public void rep_password(String p)
	{
		we=waitelement(password,20);
		we.sendKeys(p);
	}
	public void clk_button()
	{
		we=clickable(button,120);
		we.click();
	}
	public void username(String u)
	{
		we=waitelement(uid, 20);
		we.sendKeys(u);
	}
	public void user_password(String p1)
	{
		we=waitelement(pwd, 20);
		we.sendKeys(p1);
	}
	public void clk_submit()
	{
		we=clickable(submit, 20);
		we.click();
	}
	//method for doing registration
	public void registration(String em,String rep_pwd)
	{
		this.eid(em);
		this.rep_password(rep_pwd);
		this.clk_button();
		
	}
	// method for doing login
	public void login(String us_na,String us_pwd)
	{
		this.username(us_na);
		this.user_password(us_pwd);
		this.clk_submit();
	}
	
	
		
	}
	
	


