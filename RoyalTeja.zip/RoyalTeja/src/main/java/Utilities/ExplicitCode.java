package Utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitCode {
protected static WebDriver dr;
static int counter=1;

public WebElement waitElement(By locator, int timeout) {
	WebElement e= null;
	try {
	
	WebDriverWait wait= new WebDriverWait(dr,timeout);
	e=wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	System.out.println("element is loacted");
	}
	catch(Exception w){
		System.out.println("element not loacted");
	}
	return e;
}
public WebElement clickElement(By locator, int timeout) {
	WebElement e= null;
	try {
	
	WebDriverWait wait= new WebDriverWait(dr,timeout);
	e=wait.until(ExpectedConditions.elementToBeClickable(locator));
	System.out.println("element is loacted");
	}
	catch(Exception w){
		System.out.println("element not loacted");
	}
	return e;
}
public void Screenshot() {
	String path="C:\\excel\\petPom\\";
	String filename=counter+".png";
	File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
	File f2= new File(path+filename);
	try {
		FileUtils.copyFile(f1, f2);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		
		System.out.println(counter +"failed");	
		e.printStackTrace();
	}
	counter ++;
}
public void launchbrowser(String browser,String url) {
	if(browser.contains("chrome")) {
		String s="src\\test\\resources\\Drivers\\chromedriver_v79.exe";
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get(url);
		dr.manage().window().maximize();
	}else if(browser.contains("firefox")) {
		String s="src\\test\\resources\\Drivers\\geckodriver_v73.exe";
		System.setProperty("webdriver.geckodriver.driver",s);
		dr=new FirefoxDriver();
		dr.get(url);
		dr.manage().window().maximize();
	}
}
}
