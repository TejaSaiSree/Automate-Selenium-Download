package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.ExplicitCode;

public class Firstpage {
	WebDriver dr;
	ExplicitCode e;
	public Firstpage(WebDriver dr) {
	 this.dr=dr;
	 e=new ExplicitCode();
	}
	By main=By.xpath("//div[@class='headerMainToolbar__menu']//button");
	By Plan=By.xpath("//div[@class='headerSidenav__column headerSidenav__column--main']//ul//li//a[1]");
	By close=By.xpath("//*[@id=\"rciHeaderCloseSidenav\"]/figure");
	By ship=By.xpath("//div[@class='headerTopNav__base']//div[2]/a");
	By Rhapsody=By.xpath("/html/body/div[1]/div[2]/div[1]/div/div[6]/div/section/div/div[16]/a/div/figure/div");
	By deck=By.xpath("//div[@class='filterSetDestination__base']//div//div[3]");
	By eight=By.xpath("//select[@class='deck-dropdown']//option[7]");
	By royal=By.xpath("//section[@class='deck__info-panel']//section[2]//div[2]//section[5]//h4");
// public boolean search() {
//	 boolean b= dr.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div/div/div[10]/div/div[4]/div/div[2]/div/div[2]/div/div/div[2]/a")).isDisplayed();
//	 return b;
// }
public void mainf() {
	WebElement we= e.clickElement(main, 100);
	we.click();
}
public void planf() {
	WebElement we= e.clickElement(Plan, 100);
	we.click();
}
public void closef() {
	WebElement we= e.clickElement(close, 100);
	we.click();
}
public void shipf() {
	WebElement we= e.clickElement(ship, 100);
	we.click();
}
public void Rahpf() {
	WebElement we= e.clickElement(Rhapsody, 100);
	we.click();
}
public void deckf() {
	WebElement we= e.clickElement(deck, 100);
	we.click();
}
public void eightf() {
	WebElement we= e.clickElement(eight, 100);
	we.click();
}
public String royals1() {
	WebElement we= e.clickElement(royal, 100);
	String s= we.getText();
	return s;
}
public void rp() {
	this.mainf();
	this.planf();
	this.closef();
	this.shipf();
	this.Rahpf();
	this.deckf();
	this.eightf();
}
}
