package Testng;


import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.Firstpage;
import Utilities.ExplicitCode;

public class NewTest extends ExplicitCode {
	WebDriver dr;
	Firstpage p;
  @BeforeClass
  public void f() {
	launchbrowser("chrome","https://www.royalcaribbean.com/alaska-cruises");
  }
  @Test
  public void f1() {
	 p= new Firstpage(dr);
//	boolean s= p.search();
//	Assert.assertTrue(s);
	p.rp();
	String s=p.royals1();
	if(s.contains("Royal")) {
		Assert.assertTrue(s.contains("Royal"));
		
	}else {
	Assert.assertTrue(s.contains("Royal"));
	System.out.println("Does not meet my requirements");
	}
  }
}
