package TestRunner;

import org.testng.annotations.Test;



import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="src\\main\\resources\\Feature3",glue="AddP")
public class testrunner4 extends AbstractTestNGCucumberTests{

}
