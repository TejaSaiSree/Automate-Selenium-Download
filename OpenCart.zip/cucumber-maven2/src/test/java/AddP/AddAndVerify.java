package AddP;

import org.openqa.selenium.WebDriver;

import Sauce.AddandVerifyP;
import Sauce.Search;
import Utiles.ExplicitCode;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excel_utilities.getexcel;

public class AddAndVerify extends getexcel {
	WebDriver dr;
	
	 AddandVerifyP h= new  AddandVerifyP (dr);
	 
	ExplicitCode e= new ExplicitCode();
	getexcel g= new getexcel();
	@Given("^launch the browser$")
	public void launch_the_browser() throws Throwable {
		e.launchbrowser("chrome");
		 g.getExcel("Sheet1");   
	}

	@When("^AddAndVerify  with the valid details(\\d+)$")
	public void addandverify_with_the_valid_details(int arg1) throws Throwable {
		int row=arg1;
		  
		  h.AddVerify();
	}

	@Then("^verify the AddAndVerify product$")
	public void verify_the_AddAndVerify_product() throws Throwable {
	    String r=h.GetName();
	    
	    if(r.contains("MacBook")) {
	    	System.out.println("Added to cart");
	    }else {
	    	System.out.println("not added to cart");
	    }
	}
}
