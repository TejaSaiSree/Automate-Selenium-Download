package SearchP;

import org.openqa.selenium.WebDriver;

import Sauce.Homepage;
import Sauce.RegisterPage;
import Sauce.Search;
import Utiles.ExplicitCode;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excel_utilities.getexcel;

public class SearchProduct extends getexcel {
	WebDriver dr;
	
	 Search h= new  Search(dr);
	 
	ExplicitCode e= new ExplicitCode();
	getexcel g= new getexcel();
	@Given("^launch the browser$")
	public void launch_the_browser() throws Throwable {
		e.launchbrowser("chrome");
		 g.getExcel("Sheet1"); 
	}

	@When("^Search  with the invalid details(\\d+)$")
	public void search_with_the_invalid_details(int arg1) throws Throwable {
	  int row=arg1;
	  String r=testdata[row][5];
	  h.searchtheproduct(r);
	}

	@Then("^verify the Search product$")
	public void verify_the_Search_product() throws Throwable {
	    String q=h.errormessage();
	    if(q.contains("no product")) {
	    	System.out.println(q); 
	    }else {
	    	System.out.println("search success");
	    }
	}
}
