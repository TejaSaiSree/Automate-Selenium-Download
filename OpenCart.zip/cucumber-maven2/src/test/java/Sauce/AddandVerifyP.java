package Sauce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utiles.ExplicitCode;

public class AddandVerifyP {
	WebDriver dr;
	ExplicitCode e;

	public AddandVerifyP(WebDriver dr){
		this.dr=dr;
		e=new ExplicitCode();
	}
	By product=By.xpath("/html/body/div[2]/div/div/div[3]/div[1]/div/div[1] ");
	By addtocart=By.xpath("//button[@id='button-cart']");
	By shoppingcart=By.xpath("//*[@id='cart']//button");
	By viewcart=By.xpath("//*[@id='cart']//following::a[3]");
	By bookname=By.xpath("//*[@class='table-responsive']//following::a[2]");
	public void ClickP() {
		WebElement e_id=e.clickable(product, 20);
		e_id.click();
	}
	public void ClickA() {
		WebElement e_id=e.clickable(addtocart, 20);
		e_id.click();
	}
	public void ClickS() {
		WebElement e_id=e.clickable(shoppingcart, 20);
		e_id.click();
	}
	public void ClickV() {
		WebElement e_id=e.clickable(viewcart, 20);
		e_id.click();
	}
	public String GetName() {
		WebElement e_id=e.waitelement(bookname, 20);
		String r=e_id.getText();
		return r;
	}
	public void AddVerify() {
		this.ClickP();
		this.ClickA();
		this.ClickS();
		this.ClickV();
	}
}
