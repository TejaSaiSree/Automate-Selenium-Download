package Sauce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utiles.ExplicitCode;

public class Homepage {
WebDriver dr;
ExplicitCode e;

public Homepage(WebDriver dr){
	this.dr=dr;
	e=new ExplicitCode();
}

By products=By.xpath("//div[@class='product_label']");
By pnmae=By.xpath("//a[@id='item_4_title_link']//div");
public String getp(){
System.out.println("inn getp");
WebElement e_id=e.waitelement(products, 20);
String s= e_id.getText();
return s;
}
public String getpro(){
	System.out.println("inn getpro");
WebElement e_id=e.waitelement(pnmae, 20);
String s= e_id.getText();
return s;
}
}
