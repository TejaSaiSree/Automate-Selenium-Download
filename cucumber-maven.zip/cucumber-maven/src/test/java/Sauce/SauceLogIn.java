package Sauce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utiles.ExplicitCode;

public class SauceLogIn {
	WebDriver dr;
ExplicitCode e;


  
public SauceLogIn(WebDriver dr){
	this.dr=dr;
	e= new ExplicitCode();
}
By username=By.xpath("//input[@id='user-name']");
By password=By.xpath("//input[@id='password']");
By Btn= By.xpath("//input[@class='btn_action']");
public void uname(String usname){
WebElement e_id=e.waitelement(username, 20);
e_id.sendKeys(usname);	
System.out.println("after enetring the username");
}
public void password(String pword){
WebElement e_id=e.waitelement(password, 20);
e_id.sendKeys(pword);
System.out.println("after entering the password");
}
public void btn1(){
WebElement e_id=e.waitelement(Btn, 20);	
e_id.click();
System.out.println("after clicking the button");
}
public void login(String un,String p){
	System.out.println("after enetring the login");
	this.uname(un);
	this.password(p);
	this.btn1();
}

//public String gettitle(){
//	String s=dr.getTitle();
//	return s;
//}
}
