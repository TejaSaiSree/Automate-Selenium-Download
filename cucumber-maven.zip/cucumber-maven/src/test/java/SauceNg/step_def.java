package SauceNg;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Sauce.Homepage;
import Sauce.SauceLogIn;
import Utiles.ExplicitCode;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class step_def {
	WebDriver dr;
	SauceLogIn s= new SauceLogIn(dr);
	 Homepage h= new  Homepage(dr);
	ExplicitCode e= new ExplicitCode();
	@Given("^launch the browser$")
	public void launch_the_browser() throws Throwable {
	  dr= e.launchbrowser("chrome");
	}

	@When("^login with the valid details$")
	public void login_with_the_valid_details() throws Throwable {
	   s.login("standard_user","secret_sauce");
	
	}

	@Then("^verify the second book name$")
	public void verify_the_second_book_name() throws Throwable {
		
		   String s1=h.getp();
		   String s2=h.getpro();   
	   if(s1.contains("Products")) {
			  System.out.println("pass"); 
		   }else {
			   System.out.println("fail");
		   }
	   if(s2.contains("Backpack")) {
			  System.out.println("pass"); 
		   }else {
			   System.out.println("fail");
		   }
	}
}
