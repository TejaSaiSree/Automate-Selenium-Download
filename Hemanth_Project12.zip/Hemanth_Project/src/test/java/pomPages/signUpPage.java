package pomPages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.ExplicitCode;

public class signUpPage {
	WebDriver dr;
	ExplicitCode ec;
public signUpPage(WebDriver dr) {
	this.dr=dr;
	ec= new ExplicitCode();
	
}
By signup=By.xpath("//ul[@class='navbar-nav ml-auto']//li[8]//a");
By username=By.xpath("//input[@id='sign-username']");
By Password=By.xpath("//input[@id='sign-password']");
By signBtn=By.xpath("//*[@id=\"signInModal\"]/div/div/div[3]/button[2]");
public void sendKeysUsername(String q) {
	 WebElement a=ec.waitelement(username, 20);
	 a.sendKeys(q);
}
public void clicksignup() {
	 WebElement a=ec.clickable(signup, 20);
	 a.click();
}
public void sendKeyspassword(String q) {
	 WebElement a=ec.waitelement(Password, 20);
	 a.sendKeys(q);
}
public void clicksignbtn() {
	 WebElement a=ec.clickable(signBtn, 20);
	 a.click();
}
public void alert() 
{
    try {
		Thread.sleep(4000);
		} 
    catch(InterruptedException e) 
       {
	 	e.printStackTrace();
	   }
 
 Alert alt=dr.switchTo().alert();
  alt.accept();
  
	 }
public void signUp(String username,String password) {
	this.clicksignup();
	this.sendKeysUsername(username);
	this.sendKeyspassword(password);
	this.clicksignbtn();
	this.alert();
}
}
